import org.junit.Before;
import org.junit.Test;

import calculator.Calculator;
import calculator.SimpleCalculator;

import static org.junit.Assert.*;

public class SimpleCalculatorTest {
  Calculator c1;

  @Before
  public void setUp() {
    c1 = new SimpleCalculator();
  }

  @Test
  public void testSimpleCalculator() {
    c1.input('1');
    assertEquals("1",c1.getResult());
    c1.input('+');
    assertEquals("1+",c1.getResult());
    c1.input('1');
    assertEquals("1+1",c1.getResult());
    c1.input('=');
    assertEquals("2",c1.getResult());
    c1.input('=');
    assertEquals("2",c1.getResult());
    c1.input('+');
    assertEquals("2+",c1.getResult());
    c1.input('3');
    //assertEquals(3,c1.getOperand2());
    assertEquals("2+3",c1.getResult());
    c1.input('=');
    assertEquals("5",c1.getResult());
    c1.input('C');
    assertEquals("",c1.getResult());
  }
}