package betterpizza;

import java.util.HashMap;
import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

public class CheesePizza extends AlaCartePizza {
  /**
   * Create a pizza given its crust type, size and toppings.
   *
   * @param size is the Size Enum, representing the size of pizza
   * @param crust is a Crust Enum, representing the crust type
   */
  protected CheesePizza(Size size, Crust crust) {
    Map<ToppingName, ToppingPortion> toppings = new HashMap<ToppingName, ToppingPortion>();
    toppings.put(ToppingName.Cheese, ToppingPortion.Full);
    toppings.put(ToppingName.Sauce, ToppingPortion.Full);
    super(size, crust, toppings);
  }
  public static class CheesePizzaBuilder extends AlaCartePizzaBuilder {
    @Override
    public ObservablePizza build() {
      return new CheesePizza(this.s1, this.c1);
    }
  }
}
