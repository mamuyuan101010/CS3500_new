import org.junit.Before;
import org.junit.Test;

import betterpizza.CheesePizza;
import betterpizza.ObservablePizza;
import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

import static org.junit.Assert.*;

public class CheesePizzaTest {
  ObservablePizza cheese;

  @Before
  public void setUp() {
    cheese = new CheesePizza.CheesePizzaBuilder()
            .crust(Crust.Thin)
            .size(Size.Large)
            .build();
  }

  @Test
  public void testCost() {
    assertEquals(9, cheese.cost(), 0.01);
  }

  @Test
  public void testHasTopping() {
    assertEquals(ToppingPortion.Full, cheese.hasTopping(ToppingName.Cheese));
    assertEquals(ToppingPortion.Full, cheese.hasTopping(ToppingName.Sauce));
    assertNull(cheese.hasTopping(ToppingName.Onion));
  }

}